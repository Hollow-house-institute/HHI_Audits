
# Governance Telemetry ↔ Audit Evidence Binding

This table maps each telemetry field defined in the HHI governance telemetry schema to its audit purpose. Audit logging best practices emphasise capturing enough context—actor identity, target object, action, timestamp and outcome—to reconstruct events and support compliance【291569728454529†L148-L152】.

| Telemetry field | Audit purpose | Explanation |
|---|---|---|
| **actor** | Accountability | Identifies the human or system responsible for the action, enabling attribution of decisions and meeting accountability requirements【291569728454529†L148-L152】. |
| **decision_boundary** | Authority enforcement | Documents the permitted scope of the decision and shows that actions were taken within defined boundaries. |
| **escalation_state** | Risk containment | Indicates the current risk level and whether incidents have been escalated, enabling auditors to verify that escalating risks were detected and handled appropriately. |
| **stop_authority_trigger** | Human override evidence | Shows whether a human override or system pause was invoked, demonstrating compliance with oversight and intervention requirements【793718485976795†L93-L95】. |
| **timestamp** | Traceability | Provides a chronological record that allows auditors to reconstruct the sequence of events and correlate actions across systems【291569728454529†L166-L170】. |
| **rationale** | Audit defensibility | Supplies the human‑readable reasoning behind actions, enabling independent review of decisions and demonstrating that interventions were justified. |
| **intervention_result** | Continuous assurance | Captures the outcome of the intervention, allowing organisations to monitor effectiveness over time and improve controls. |
| **additional_metadata** | Contextual completeness | Contains supplementary information (e.g. model version, risk scores) that helps auditors fully understand the context of a decision and verify compliance. |

By binding telemetry fields to specific audit purposes, organisations ensure that governance telemetry is not merely operational data but serves as defensible evidence for compliance, risk management and human oversight. 
