# Deployment Guide

## Local Setup

### 1. Create a virtual environment

```bash
python -m venv .venv
source .venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Confirm model path

The service expects the model directory here:

```text
./trained_ancient_knowledge_ai
```

That directory should contain Hugging Face-compatible model and tokenizer files.

### 4. Run the service

```bash
python deploy_ancient_knowledge_ai.py
```

The API will listen on:

```text
http://0.0.0.0:5000/generate
```

## Test Request

```bash
curl -X POST http://127.0.0.1:5000/generate \
  -H "Content-Type: application/json" \
  -d '{"prompt":"What is ancient knowledge?"}'
```

## Recommended Production Deployment

For production or public exposure, do not run Flask’s built-in development server directly. Use Gunicorn or another WSGI server.

```bash
gunicorn -w 1 -b 0.0.0.0:5000 deploy_ancient_knowledge_ai:app
```

For larger models, begin with one worker unless GPU memory has been tested.

## Docker Deployment

```bash
docker build -t ancient-knowledge-ai .
docker run -p 5000:5000 ancient-knowledge-ai
```

## Environment Variables To Add

Recommended future variables:

```text
MODEL_PATH=./trained_ancient_knowledge_ai
MAX_LENGTH=150
TEMPERATURE=0.7
PORT=5000
ENABLE_TELEMETRY=true
GOVERNANCE_MODE=enforced
```

## Deployment Risks

- Model path is hard-coded.
- No authentication protects the endpoint.
- No rate limit protects compute resources.
- No health endpoint confirms runtime readiness.
- No request size limit prevents oversized inputs.
- No structured logs support audit replay.
- No governance layer constrains prompt/output behavior.
