# Provenance and Telemetry Assessment

## Current Provenance State

The script identifies the local model path but does not bind the running service to a model version, checksum, training dataset, release tag, or governance authority record.

Current provenance signal:

```python
model_path = "./trained_ancient_knowledge_ai"
```

This is not enough for audit-grade provenance.

## Missing Provenance Fields

Recommended metadata:

- model name
- model version
- model directory checksum
- tokenizer checksum
- training dataset identifier
- training date
- fine-tuning method
- base model name
- license
- intended use
- prohibited use
- maintainer
- release tag
- repository commit
- DOI or archival reference, if applicable

## Recommended File: provenance/model_card.json

```json
{
  "model_name": "ancient_knowledge_ai",
  "model_version": "0.1.0",
  "base_model": "unknown",
  "model_path": "./trained_ancient_knowledge_ai",
  "training_dataset": "unknown",
  "training_date": "unknown",
  "maintainer": "unknown",
  "license": "unknown",
  "intended_use": "local text generation",
  "prohibited_use": [
    "unverified historical claims presented as fact",
    "medical, legal, financial, or safety-critical advice",
    "identity-based profiling or harmful classification"
  ],
  "provenance_status": "incomplete"
}
```

## Recommended Telemetry Controls

Telemetry should support accountability without over-collecting sensitive content.

Recommended default:

- log prompt hash, not raw prompt
- log output hash, not raw output
- log model version and generation parameters
- log decision outcome
- log errors
- log Stop Authority state

Avoid by default:

- raw user prompt storage
- raw generated output storage
- user identifiers
- IP address retention unless required and disclosed

## Minimal Audit-Ready Telemetry Event

```json
{
  "event_id": "uuid",
  "timestamp": "ISO-8601 UTC",
  "trace_id": "uuid",
  "actor": "api_user",
  "system": "ancient_knowledge_ai",
  "action": "generate_text",
  "prompt_hash": "sha256",
  "output_hash": "sha256",
  "model_version": "0.1.0",
  "decision_boundary": "allow",
  "stop_authority": "inactive",
  "outcome": "success"
}
```

## Assessment

Audit readiness: low.

Reason: the service runs inference but does not yet preserve enough metadata to reconstruct model identity, request handling, governance decisions, or output lineage.

Priority fixes:

1. Add provenance metadata.
2. Add append-only telemetry.
3. Add `/health` and `/governance` endpoints.
4. Add Stop Authority gating.
5. Add request validation and error handling.
6. Replace Flask dev server with Gunicorn for deployment.
