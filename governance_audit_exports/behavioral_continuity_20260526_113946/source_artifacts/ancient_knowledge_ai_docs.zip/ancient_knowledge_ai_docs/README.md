# Ancient Knowledge AI Deployment

## Purpose

`deploy_ancient_knowledge_ai.py` exposes a locally stored causal language model through a Flask HTTP API.

The service loads:

- a tokenizer from `./trained_ancient_knowledge_ai`
- a causal language model from `./trained_ancient_knowledge_ai`
- a Flask endpoint at `/generate`

The endpoint accepts a JSON payload containing a `prompt` field and returns generated text.

## Runtime Flow

1. Flask receives a `POST /generate` request.
2. The request body is parsed as JSON.
3. The `prompt` field is extracted.
4. The prompt is tokenized with Hugging Face Transformers.
5. The model generates a response.
6. The generated output is decoded into text.
7. The response is returned as JSON.

## API Contract

### Endpoint

```http
POST /generate
Content-Type: application/json
```

### Request Body

```json
{
  "prompt": "Explain the symbolic role of water in ancient knowledge systems."
}
```

### Response Body

```json
{
  "response": "...generated model output..."
}
```

## Current Limitations

The current script is a minimal prototype. It does not yet include:

- request validation
- authentication
- rate limiting
- structured telemetry
- prompt/output logging controls
- model version metadata
- error handling
- health checks
- governance boundary enforcement
- provenance records
- deployment hardening

## Recommended Production Boundary

This service should not be treated as production-ready until the deployment includes runtime governance controls, provenance metadata, telemetry logging, model/version binding, and operational safeguards.
